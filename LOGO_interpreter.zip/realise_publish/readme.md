执行文件：proj0.app  
输入文件：input.logo  
输出文件：output.logo  
命令详解见PDF文件